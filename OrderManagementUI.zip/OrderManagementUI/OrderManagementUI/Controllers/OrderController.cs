﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OrderManagementUI.Models;
using System.Net;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace MVCApplication.Controllers
{

    public class OrderController : Controller
    {
        private readonly ILogger<OrderController> _logger;

        public object Products { get; private set; }

        public OrderController(ILogger<OrderController> logger)
        {
            _logger = logger;
        }
        
        public async Task<IActionResult> GetAllOrders()
        {
            List<Orders> orderList = new List<Orders>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://ordermanagementmicroservice.apps.pas-useast1.gcp-wipro.com/api/v1/Order"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    orderList = JsonConvert.DeserializeObject<List<Orders>>(apiResponse);
                }
            }
            return View(orderList);
        }
        public ViewResult GetOrder() => View();
        [HttpPost]
        public async Task<IActionResult> GetOrder(int id)
        {
            Orders orderResponse = new Orders();
            Orders order = new Orders();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://ordermanagementmicroservice.apps.pas-useast1.gcp-wipro.com/api/v1/Order/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var serializeOrderJsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(apiResponse);
                    
                      orderResponse = JsonConvert.DeserializeObject<Orders>(apiResponse);
                    if(orderResponse == null)
                    {
                       
                        order = orderResponse;
                    }
                    //else if(orderResponse.== "Not Found")
                    //{
                    //    orderResponse.id = id.ToString();
                    //    order = orderResponse;
                    //}
                   else
                    {
                        order = orderResponse;
                    }
                }
            }
            return View(order);
        }
        
        public ViewResult CreateOrder() => View();
        

        [HttpPost]
        public async Task<IActionResult> CreateOrder(ProductArray productArray)
        {
            Orders createdOrder = new Orders();
            Orders firstOrderProduct = new Orders();
            Orders secondOrderProduct = new Orders();
            Product[] listProducts = new Product[1];
            Product product = new Product();
            List<Orders> createdListOrder = new List<Orders>();
            if (productArray.Products[0].Productnumber == 0 && productArray.Products[1].Productnumber == 0)
            {
                createdListOrder = new List<Orders>();
            }
            else
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(productArray), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PostAsync("https://ordermanagementmicroservice.apps.pas-useast1.gcp-wipro.com/api/v1/Order", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        createdOrder = JsonConvert.DeserializeObject<Orders>(apiResponse);
                        if (createdOrder.Products.Count == 2)
                        {
                            firstOrderProduct.id = createdOrder.id;

                            firstOrderProduct.Products.Add(new Product
                            {
                                Productnumber = createdOrder.Products[0].Productnumber,
                                Name = createdOrder.Products[0].Name,
                                Specification = createdOrder.Products[0].Specification,
                                Image = createdOrder.Products[0].Image,
                                Price = createdOrder.Products[0].Price,

                            });

                            firstOrderProduct.CreatedDate = createdOrder.CreatedDate;
                            createdListOrder.Add(firstOrderProduct);


                            secondOrderProduct.id = createdOrder.id;

                            secondOrderProduct.Products.Add(new Product
                            {
                                Productnumber = createdOrder.Products[1].Productnumber,
                                Name = createdOrder.Products[1].Name,
                                Specification = createdOrder.Products[1].Specification,
                                Image = createdOrder.Products[1].Image,
                                Price = createdOrder.Products[1].Price,

                            });

                            secondOrderProduct.CreatedDate = createdOrder.CreatedDate;

                            createdListOrder.Add(secondOrderProduct);
                        }
                        else if (createdOrder.Products.Count == 1)
                        {
                            firstOrderProduct.id = createdOrder.id;

                            firstOrderProduct.Products.Add(new Product
                            {
                                Productnumber = createdOrder.Products[0].Productnumber,
                                Name = createdOrder.Products[0].Name,
                                Specification = createdOrder.Products[0].Specification,
                                Image = createdOrder.Products[0].Image,
                                Price = createdOrder.Products[0].Price,

                            });

                            firstOrderProduct.CreatedDate = createdOrder.CreatedDate;
                            createdListOrder.Add(firstOrderProduct);
                        }
                    }

                }
            }
            return View(createdListOrder);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}
    }
}
