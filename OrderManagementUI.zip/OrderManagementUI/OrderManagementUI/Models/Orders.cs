﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace OrderManagementUI.Models
{
    public class Orders
    {
        [JsonProperty(PropertyName = "id")]
        public string id { get; set; }
        [JsonProperty(PropertyName = "products")]
        public List<Product> Products { get; set; } = new List<Product>();
       [JsonProperty(PropertyName = "createdDate")]
        public string CreatedDate { get; set; }

        public string title { get; set; }
        public string StatusCode { get; set; }
    }
}
